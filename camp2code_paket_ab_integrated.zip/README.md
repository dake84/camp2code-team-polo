# Camp2Code Paket A+B

## Architektur

`CameraSensor` veröffentlicht pro Frame ein `CameraData` mit `frame_id`, Bild, Linien, Prozessor und Parametern. `CameraMode` publiziert `DrivingState` mit derselben ID. `CameraCar` verwaltet beide Datenströme und den begrenzten `FrameRingBuffer` (60 Einträge). Der Recorder liest diesen Puffer und schreibt Rohbild plus CSV. Dashboard-Overlays werden ausschließlich für die Anzeige erzeugt.

`CameraCar` erbt von `SensorCar`, das von `SonicCar` und `BaseCar` erbt. Vorhandene IR-/Ultraschall-Sensorinstanzen veröffentlichen über diese eine Fahrzeuginstanz ihre Messwerte. `SensorSnapshot` enthält getrennte Zeitstempel und Messalter; keine erneute Hardwareinitialisierung im Recorder.

## CSV-Schema

`frame_id` identifiziert den Kameraframe; `image` ist der JPEG-Dateiname. `camera_timestamp_ns` ist die Systemzeit der Kameraveröffentlichung, `camera_monotonic_ns` die monotone Uhr. `driving_timestamp_ns` bezeichnet den Entscheidungszeitpunkt. `timestamp_ns` und `monotonic_ns` bezeichnen den Recorderzeitpunkt. `camera_age_ns`, `infrared_age_ns` und `ultrasonic_age_ns` geben das Alter zur Recorderzeit an. `infrared_*` und `ultrasonic_*` sind die jeweiligen Messzeitpunkte. `ir_1` bis `ir_5` sind normierte IR-Werte, `ultrasonic_cm` der Abstand in Zentimetern. `speed` ist ein Steuerwert und keine gemessene Geschwindigkeit. `steering_angle` ist der tatsächlich veröffentlichte Lenkwinkel der Fahrentscheidung. `lane_count`, `lane_left_m/b`, `lane_right_m/b` enthalten erkannte Linien, `processor_name`, `processing_parameters`, `driving_mode` die verwendete Verarbeitung bzw. den Modus. `data_status=no_driving_state` markiert fehlende Entscheidungen; Fahrfelder bleiben leer.

## Umgang mit fehlenden Entscheidungen

Recorder arbeitet den Ringbuffer in Reihenfolge ab. Wenn bei Aufnahme eines Frames keine Entscheidung vorhanden ist, wird die Zeile als `no_driving_state` geschrieben und nicht nachträglich geändert. Ein Controller kann nach dem Recorder-Tick noch eine Entscheidung erzeugen: diese ist dann **nicht** nachgetragen. Zur Erhöhung der Zuordnungstreue ist eine Verzögerungsfrist im Recorder eine mögliche spätere Erweiterung. Frames, die bereits aus dem Ringbuffer verdrängt wurden, können nicht mehr aufgezeichnet werden. Bei Aufzeichnung mit 5 Hz und Kamera mit 25 Hz kann ein Puffer mit 60 Einträgen kurzfristige Verzögerungen aufnehmen.

## Installation

Im Projektroot entpacken: `unzip -o camp2code_paket_ab_integrated.zip`. Vorher Git-Commit und Backup anlegen. Die Dashboards initialisieren weiterhin die Kamera; IR-/US-Threads müssen beim jeweiligen Startskript auf derselben `CameraCar`-Instanz gestartet werden, falls Multisensorwerte benötigt werden. Keine zweite Fahrzeug- oder Sensorinstanz anlegen.

## Tests

`python -m compileall -q .` und `python -m unittest discover -s tests -p 'test_*.py'`.

## Einschränkungen

- Hardware- und Kamera-Integration auf Raspberry Pi nicht getestet.
- `CameraDataProcessed` bleibt für bestehende Verbraucher als Übergangsschnittstelle erhalten.
- IR/US-Werte werden zum Recorderzeitpunkt gelesen, nicht historisch je Kameraframe gespeichert. Ihre Messalter machen die zeitliche Abweichung sichtbar.
- Publizierte NumPy-Arrays sind weiterhin referenziert und dürfen von Verbrauchern nicht verändert werden. Dashboard-Overlays arbeiten auf Kopien.
- Kamera- und Sensor-Startskripte müssen dieselbe `CameraCar`-Instanz verwenden; der Export beweist dies nicht für alle Programme.
